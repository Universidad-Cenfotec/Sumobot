import board
from ideaboard import IdeaBoard

ib = IdeaBoard()

## CODIGO PRINCIPAL ##

while True:
    ib.pixel = (150,0,255)